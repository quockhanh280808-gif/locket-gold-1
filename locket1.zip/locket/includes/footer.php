<footer class="text-center mt-5 pt-4 border-top">
  <p class="small text-secondary">© 2024 Locket Gold - Hệ thống nâng cấp Premium tự động</p>
</footer>
</body>
</html>
